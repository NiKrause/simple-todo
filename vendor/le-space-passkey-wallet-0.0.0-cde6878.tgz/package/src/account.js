/**
 * The passkey as a viem smart account on Calibur and EntryPoint v0.8.
 */
import { signP256Challenge } from '@le-space/orbitdb-identity-provider-webauthn-did/standalone';
import { getAddress, hexToBytes, isAddress } from 'viem';
import {
  entryPoint08Abi,
  getUserOperationHash,
  toSmartAccount,
} from 'viem/account-abstraction';
import { getChainId } from 'viem/actions';

import { caliburAbi } from './abi.js';
import {
  decodeExecuteUserOpCallData,
  encodeExecuteUserOpCallData,
  encodeUserOperationSignature,
  encodeWebAuthnAuth,
  getCaliburStubSignature,
  getKeyHash,
  toWebAuthnP256Key,
} from './calibur.js';
import { ENTRY_POINT_ADDRESS } from './constants.js';

/**
 * @typedef {import('viem').Address} Address
 * @typedef {import('viem').Hex} Hex
 * @typedef {import('./calibur.js').Key} Key
 */

/**
 * What `getP256CredentialDescriptor` returns: the passkey's credential id, its
 * P-256 key as 32-byte coordinates, and the rpId it is registered under.
 * @typedef {import('@le-space/orbitdb-identity-provider-webauthn-did/standalone').P256CredentialDescriptor} P256CredentialDescriptor
 */

/**
 * The client a smart account reads chain state through; a public client will
 * do.
 * @typedef {import('viem').Client<
 *   import('viem').Transport,
 *   import('viem').Chain | undefined,
 *   import('viem').JsonRpcAccount | import('viem').LocalAccount | undefined
 * >} AccountClient
 */

/**
 * The smart account `toCaliburPasskeyAccount` returns: a viem SmartAccount for
 * EntryPoint v0.8, extended with Calibur's ABI, the passkey descriptor, its
 * Calibur key and key hash.
 * @typedef {import('viem/account-abstraction').SmartAccount<
 *   import('viem/account-abstraction').SmartAccountImplementation<
 *     typeof entryPoint08Abi,
 *     '0.8',
 *     {
 *       abi: typeof caliburAbi,
 *       descriptor: P256CredentialDescriptor,
 *       key: Key,
 *       keyHash: Hex,
 *     }
 *   >
 * >} CaliburPasskeyAccount
 */

/**
 * The verification gas a passkey user operation is given at least.
 *
 * Measured on a Sepolia fork (test/fork, to within 1k gas): a user operation
 * with a real passkey signature needs a verificationGasLimit of about 81k
 * where the P-256 precompile (EIP-7951, at 0x100) exists, and about 370k
 * without it, where webauthn-sol verifies in Solidity (FreshCryptoLib). With
 * the stub signature it needs about 72k either way: the stub stops before the
 * P-256 verification — see `getCaliburStubSignature` — so an estimate made
 * with it falls short. 800k covers the precompile-less case with room, the
 * floor viem's Coinbase account sets for WebAuthn owners too. EntryPoint v0.8
 * charges no penalty for unused verification gas, but the limit raises the
 * prefund; pass less for a chain known to have the precompile.
 */
export const DEFAULT_VERIFICATION_GAS_LIMIT = 800_000n;

/**
 * The same passkey as `signP256Challenge` expects it; refuses anything that
 * could not sign, before a smart account is built around it.
 * @param {unknown} descriptor
 * @returns {P256CredentialDescriptor}
 */
function readDescriptor(descriptor) {
  const d = /** @type {P256CredentialDescriptor} */ (descriptor);
  if (
    !d ||
    typeof d !== 'object' ||
    !(d.rawCredentialId instanceof Uint8Array) ||
    d.rawCredentialId.length === 0 ||
    typeof d.rpId !== 'string' ||
    !d.rpId
  ) {
    throw new TypeError(
      'A passkey descriptor from getP256CredentialDescriptor() is needed'
    );
  }
  return d;
}

/**
 * @param {string} method
 */
function unsupported(method) {
  return new Error(
    `${method} is not supported by the Calibur passkey account yet: Calibur verifies ERC-1271 signatures through ERC-7739 wrapping, which this package does not build`
  );
}

/**
 * A viem smart account for a Calibur account whose passkey is registered.
 *
 * - `signUserOperation` computes the EntryPoint v0.8 user operation hash, has
 *   the passkey sign exactly those 32 bytes with `signP256Challenge` (one
 *   WebAuthn prompt, user verification required) and encodes Calibur's
 *   `abi.encode(keyHash, abi.encode(WebAuthnAuth), hookData)`.
 * - `encodeCalls` batches through Calibur's `executeUserOp`: all calls run in
 *   one `BatchedCall`, and one failure reverts them all.
 * - The account is already an EIP-7702 delegate, so there are no factory
 *   arguments; set it up first with `createCaliburPasskeySetup`.
 * - `signMessage` and `signTypedData` throw: ERC-1271 on Calibur goes through
 *   ERC-7739, which this package does not implement.
 *
 * Bundler and paymaster are the app's: pass this account to a bundler client
 * the app creates (`createCaliburBundlerClient` takes URLs and headers).
 *
 * @param {{
 *   client: AccountClient,
 *   address: Address,
 *   descriptor: P256CredentialDescriptor,
 *   verificationGasLimit?: bigint | undefined,
 *   nonceKeyManager?: import('viem').NonceManager | undefined,
 * }} parameters
 *   `client` reads chain state (nonce, chain id, code); `address` is the
 *   Calibur account, the EOA the setup created; `verificationGasLimit` is the
 *   floor for user operations (default `DEFAULT_VERIFICATION_GAS_LIMIT`).
 * @returns {Promise<CaliburPasskeyAccount>}
 */
export async function toCaliburPasskeyAccount(parameters) {
  const {
    client,
    address,
    descriptor: descriptorParameter,
    verificationGasLimit = DEFAULT_VERIFICATION_GAS_LIMIT,
    nonceKeyManager,
  } = parameters ?? /** @type {any} */ ({});
  if (!client) {
    throw new TypeError('toCaliburPasskeyAccount needs a viem client');
  }
  if (typeof address !== 'string' || !isAddress(address, { strict: false })) {
    throw new TypeError('toCaliburPasskeyAccount needs the account address');
  }
  if (typeof verificationGasLimit !== 'bigint' || verificationGasLimit < 0n) {
    throw new TypeError('verificationGasLimit must be a non-negative bigint');
  }
  const descriptor = readDescriptor(descriptorParameter);
  const account = getAddress(address);
  const key = toWebAuthnP256Key(descriptor);
  const keyHash = getKeyHash(key);
  const entryPoint = /** @type {const} */ ({
    abi: entryPoint08Abi,
    address: ENTRY_POINT_ADDRESS,
    version: '0.8',
  });

  return /** @type {Promise<CaliburPasskeyAccount>} */ (
    toSmartAccount({
      client,
      entryPoint,
      nonceKeyManager,
      extend: { abi: caliburAbi, descriptor, key, keyHash },

      async decodeCalls(data) {
        return decodeExecuteUserOpCallData(data).calls;
      },

      async encodeCalls(calls) {
        return encodeExecuteUserOpCallData(calls);
      },

      async getAddress() {
        return account;
      },

      async getFactoryArgs() {
        return { factory: undefined, factoryData: undefined };
      },

      async getStubSignature() {
        return getCaliburStubSignature({ keyHash, rpId: descriptor.rpId });
      },

      async signMessage() {
        throw unsupported('signMessage');
      },

      async signTypedData() {
        throw unsupported('signTypedData');
      },

      async signUserOperation(userOperationParameters) {
        const { chainId: chainIdParameter, ...userOperation } =
          userOperationParameters;
        const chainId =
          chainIdParameter ?? client.chain?.id ?? (await getChainId(client));
        const hash = getUserOperationHash({
          chainId,
          entryPointAddress: entryPoint.address,
          entryPointVersion: entryPoint.version,
          userOperation: { ...userOperation, sender: account },
        });
        const assertion = await signP256Challenge(descriptor, hexToBytes(hash));
        return encodeUserOperationSignature({
          keyHash,
          signature: encodeWebAuthnAuth(assertion),
        });
      },

      userOperation: {
        async estimateGas(userOperation) {
          const requested = userOperation.verificationGasLimit ?? 0n;
          return {
            verificationGasLimit:
              requested > verificationGasLimit
                ? requested
                : verificationGasLimit,
          };
        },
      },
    })
  );
}

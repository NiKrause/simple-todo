/**
 * Ed25519 keystore web worker.
 *
 * Two things live here and nowhere else:
 *
 * - A signer: an Ed25519 key derived from the passkey's PRF output
 *   (`deriveSigner`). It is derived again every session, never exported,
 *   never written anywhere, and the page only ever gets `sign()`. The same
 *   passkey yields the same key on every device.
 * - The older archive flow (`generateKeypair` / `loadKeypair` /
 *   `encrypt` / `decrypt`): a random key, sealed with an AES key from the
 *   PRF seed. Its archive crosses to the page in clear on the way to and
 *   from storage, which is why the demos moved to the signer.
 */
import { generateKeyPairFromSeed } from '@libp2p/crypto/keys';

const WORKER_KDF_INFO = new TextEncoder().encode(
  'orbitdb/standalone-ed25519-keystore'
);
// Its own info string: the signer and the AES key must never share bytes.
// Bumping it rotates every derived signer, so treat it as a breaking change.
const SIGNER_KDF_INFO = new TextEncoder().encode(
  'orbitdb-identity-provider-webauthn-did:worker-signer:v1'
);

let ed25519KeyPair = null;
let aesKey = null;
let edSigner = null;
/** @type {import('@libp2p/interface').PrivateKey|null} The derived signer. */
let signerKey = null;

function asUint8Array(value) {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (ArrayBuffer.isView(value)) {
    return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
  }
  return new Uint8Array(value || []);
}

function toDetachedBuffer(bytes) {
  return bytes.buffer.slice(
    bytes.byteOffset,
    bytes.byteOffset + bytes.byteLength
  );
}

async function deriveAesKeyFromPrfSeed(prfSeedBuffer) {
  const seedBytes = asUint8Array(prfSeedBuffer);
  if (seedBytes.length === 0) {
    throw new Error('PRF seed must not be empty');
  }

  const saltHash = await crypto.subtle.digest('SHA-256', seedBytes);
  const salt = new Uint8Array(saltHash).slice(0, 16);

  const baseKey = await crypto.subtle.importKey(
    'raw',
    seedBytes,
    'HKDF',
    false,
    ['deriveKey']
  );

  return crypto.subtle.deriveKey(
    {
      name: 'HKDF',
      hash: 'SHA-256',
      salt,
      info: WORKER_KDF_INFO,
    },
    baseKey,
    {
      name: 'AES-GCM',
      length: 256,
    },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * HKDF-SHA256 the PRF seed into an Ed25519 seed and keep the key pair.
 * Returns only the public key.
 */
async function deriveSigner(prfSeedBuffer) {
  const seedBytes = asUint8Array(prfSeedBuffer);
  if (seedBytes.length === 0) {
    throw new Error('PRF seed must not be empty');
  }
  const baseKey = await crypto.subtle.importKey(
    'raw',
    seedBytes,
    'HKDF',
    false,
    ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: 'HKDF',
      hash: 'SHA-256',
      salt: new Uint8Array(0),
      info: SIGNER_KDF_INFO,
    },
    baseKey,
    256
  );
  signerKey = await generateKeyPairFromSeed('Ed25519', new Uint8Array(bits));
  return { publicKey: new Uint8Array(signerKey.publicKey.raw) };
}

async function generateEd25519KeypairArchive() {
  ed25519KeyPair = await crypto.subtle.generateKey({ name: 'Ed25519' }, true, [
    'sign',
    'verify',
  ]);

  const publicKeySpki = new Uint8Array(
    await crypto.subtle.exportKey('spki', ed25519KeyPair.publicKey)
  );
  const privateKeyPkcs8 = new Uint8Array(
    await crypto.subtle.exportKey('pkcs8', ed25519KeyPair.privateKey)
  );

  const publicKey = publicKeySpki.slice(-32);
  const secret = privateKeyPkcs8.slice(-32);
  const EdSigner = await import('@le-space/ucanto-principal/ed25519');
  edSigner = await EdSigner.derive(secret);

  return {
    publicKey,
    archive: edSigner.toArchive(),
  };
}

async function loadKeypairFromArchive(archive) {
  if (!archive || typeof archive !== 'object') {
    throw new Error('Unsupported archive: expected object');
  }

  // Preferred format: UCAN signer archive { id, keys }.
  if (typeof archive.id === 'string' && archive.keys) {
    const EdSigner = await import('@le-space/ucanto-principal/ed25519');
    edSigner = EdSigner.from({
      id: archive.id,
      keys: Object.fromEntries(
        Object.entries(archive.keys).map(([did, key]) => [
          did,
          asUint8Array(key),
        ])
      ),
    });
    ed25519KeyPair = null;
    return;
  }

  // Backward-compatible format: pkcs8/spki archive.
  if (archive.algorithm !== 'Ed25519') {
    throw new Error('Unsupported archive format');
  }
  const privateKeyBytes = asUint8Array(archive.privateKeyPkcs8);
  const publicKeyBytes = asUint8Array(archive.publicKeySpki);
  if (privateKeyBytes.length === 0 || publicKeyBytes.length === 0) {
    throw new Error('Invalid archive: missing key material');
  }
  const privateKey = await crypto.subtle.importKey(
    'pkcs8',
    toDetachedBuffer(privateKeyBytes),
    { name: 'Ed25519' },
    true,
    ['sign']
  );

  const publicKey = await crypto.subtle.importKey(
    'spki',
    toDetachedBuffer(publicKeyBytes),
    { name: 'Ed25519' },
    true,
    ['verify']
  );

  ed25519KeyPair = { privateKey, publicKey };
  const EdSigner = await import('@le-space/ucanto-principal/ed25519');
  edSigner = await EdSigner.derive(privateKeyBytes.slice(-32));
}

async function encrypt(plaintextBuffer) {
  if (!aesKey) {
    throw new Error('Keystore not initialized');
  }

  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    aesKey,
    plaintextBuffer
  );

  return {
    ciphertext: new Uint8Array(ciphertext),
    iv,
  };
}

async function decrypt(ciphertextBuffer, ivBuffer) {
  if (!aesKey) {
    throw new Error('Keystore not initialized');
  }

  const plaintext = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: ivBuffer },
    aesKey,
    ciphertextBuffer
  );

  return {
    plaintext: new Uint8Array(plaintext),
  };
}

async function sign(dataBuffer) {
  if (signerKey) {
    return { signature: await signerKey.sign(asUint8Array(dataBuffer)) };
  }
  if (!ed25519KeyPair && !edSigner) {
    throw new Error('Ed25519 keypair not generated');
  }

  if (edSigner) {
    const signature = await edSigner.sign(asUint8Array(dataBuffer));
    return {
      signature: asUint8Array(signature.raw),
    };
  }

  const signature = await crypto.subtle.sign(
    { name: 'Ed25519' },
    ed25519KeyPair.privateKey,
    dataBuffer
  );

  return {
    signature: new Uint8Array(signature),
  };
}

async function verify(dataBuffer, signatureBuffer) {
  if (signerKey) {
    return {
      valid: await signerKey.publicKey.verify(
        asUint8Array(dataBuffer),
        asUint8Array(signatureBuffer)
      ),
    };
  }
  if (!ed25519KeyPair && !edSigner) {
    throw new Error('Ed25519 keypair not generated');
  }

  if (edSigner) {
    const DagUcanSignature = await import('@ipld/dag-ucan/signature');
    const signature = DagUcanSignature.create(
      DagUcanSignature.EdDSA,
      asUint8Array(signatureBuffer)
    );
    const valid = await edSigner.verify(asUint8Array(dataBuffer), signature);
    return { valid };
  }

  const valid = await crypto.subtle.verify(
    { name: 'Ed25519' },
    ed25519KeyPair.publicKey,
    signatureBuffer,
    dataBuffer
  );

  return { valid };
}

function postSuccess(id, result, transferables = []) {
  self.postMessage({ id, ok: true, result }, transferables);
}

function postError(id, error) {
  self.postMessage({
    id,
    ok: false,
    error: error instanceof Error ? error.message : String(error),
  });
}

self.onmessage = async (event) => {
  const msg = event.data;
  const id = msg.id;

  try {
    switch (msg.type) {
      case 'init': {
        aesKey = await deriveAesKeyFromPrfSeed(msg.prfSeed);
        postSuccess(id, { initialized: true });
        break;
      }
      case 'deriveSigner': {
        const { publicKey } = await deriveSigner(msg.prfSeed);
        const publicKeyBuffer = toDetachedBuffer(publicKey);
        postSuccess(id, { publicKey: publicKeyBuffer }, [publicKeyBuffer]);
        break;
      }
      case 'generateKeypair': {
        const { publicKey, archive } = await generateEd25519KeypairArchive();
        const publicKeyBuffer = toDetachedBuffer(publicKey);
        postSuccess(id, { publicKey: publicKeyBuffer, archive }, [
          publicKeyBuffer,
        ]);
        break;
      }
      case 'loadKeypair': {
        await loadKeypairFromArchive(msg.archive);
        postSuccess(id, { loaded: true });
        break;
      }
      case 'encrypt': {
        const result = await encrypt(msg.plaintext);
        const ciphertextBuffer = toDetachedBuffer(result.ciphertext);
        const ivBuffer = toDetachedBuffer(result.iv);
        postSuccess(id, { ciphertext: ciphertextBuffer, iv: ivBuffer }, [
          ciphertextBuffer,
          ivBuffer,
        ]);
        break;
      }
      case 'decrypt': {
        const result = await decrypt(msg.ciphertext, msg.iv);
        const plaintextBuffer = toDetachedBuffer(result.plaintext);
        postSuccess(id, { plaintext: plaintextBuffer }, [plaintextBuffer]);
        break;
      }
      case 'sign': {
        const result = await sign(msg.data);
        const signatureBuffer = toDetachedBuffer(result.signature);
        postSuccess(id, { signature: signatureBuffer }, [signatureBuffer]);
        break;
      }
      case 'verify': {
        const result = await verify(msg.data, msg.signature);
        postSuccess(id, result);
        break;
      }
      default: {
        throw new Error(`Unknown message type: ${msg.type}`);
      }
    }
  } catch (error) {
    postError(id, error);
  }
};

/**
 * Keystore Encryption Utilities
 *
 * Provides AES-GCM encryption for OrbitDB keystore private keys,
 * protected by WebAuthn credentials using PRF, largeBlob, or hmac-secret extensions.
 */

import { logger } from '@libp2p/logger';
import { buildCredentialRequestOptions } from '../webauthn/config.js';
import {
  CRYPTO_ALGORITHMS,
  KEYSTORE_ENCRYPTION_METHODS,
} from '../constants.js';
import { KeystoreEncryptionError, PrfUnavailableError } from '../errors.js';

const log = logger(
  'orbitdb-identity-provider-webauthn-did:keystore-encryption'
);
const PRF_INFO = new TextEncoder().encode('orbitdb/keystore-prf');

async function deriveKeyFromPrfSeed(prfSeed) {
  const saltHash = await crypto.subtle.digest(
    CRYPTO_ALGORITHMS.SHA_256,
    prfSeed
  );
  const salt = new Uint8Array(saltHash).slice(0, 16);
  const baseKey = await crypto.subtle.importKey(
    'raw',
    prfSeed,
    CRYPTO_ALGORITHMS.HKDF,
    false,
    ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: 'HKDF',
      hash: CRYPTO_ALGORITHMS.SHA_256,
      salt,
      info: PRF_INFO,
    },
    baseKey,
    256
  );
  return new Uint8Array(bits);
}

/**
 * The PRF output of an assertion, or null when there is none.
 *
 * This used to fall back to the raw credential id, silently, so a key
 * "wrapped with PRF" could in fact be wrapped with a value that sits in
 * localStorage in clear. Without PRF there is no secret to derive from.
 *
 * @param {PublicKeyCredential} assertion
 * @returns {{seed: Uint8Array, source: 'prf'}|null}
 */
function getPrfSeed(assertion) {
  if (!assertion) return null;
  try {
    const prfResults = assertion.getClientExtensionResults()?.prf;
    if (prfResults?.results?.first) {
      log('Using WebAuthn PRF extension for key derivation');
      return {
        seed: new Uint8Array(prfResults.results.first),
        source: KEYSTORE_ENCRYPTION_METHODS.PRF,
      };
    }
  } catch (error) {
    log('Error reading PRF extension results: %s', error.message);
  }
  log('PRF extension not available');
  return null;
}

/**
 * @param {PublicKeyCredential} assertion
 * @param {string} verb - For the message: what could not be done.
 * @returns {{seed: Uint8Array, source: 'prf'}}
 * @throws {PrfUnavailableError}
 */
function getPrfSeedOrThrow(assertion, verb) {
  const prf = getPrfSeed(assertion);
  if (!prf) {
    throw new PrfUnavailableError(
      `the authenticator returned no PRF output, so the key cannot be ${verb}`
    );
  }
  return prf;
}

/**
 * Generate a random AES-GCM secret key (256-bit)
 * @returns {Uint8Array} Secret key bytes.
 */
export function generateSecretKey() {
  return crypto.getRandomValues(new Uint8Array(32));
}

/**
 * Encrypt data with AES-GCM
 * @param {Uint8Array} data - Data to encrypt
 * @param {Uint8Array} sk - Secret key (32 bytes)
 * @returns {Promise<{ciphertext: Uint8Array, iv: Uint8Array}>}
 */
export async function encryptWithAESGCM(data, sk) {
  log('Encrypting data with AES-GCM');

  // Generate random IV (12 bytes for GCM)
  const iv = crypto.getRandomValues(new Uint8Array(12));

  // Import secret key
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    sk,
    { name: CRYPTO_ALGORITHMS.AES_GCM, length: 256 },
    false,
    ['encrypt']
  );

  // Encrypt
  const ciphertext = await crypto.subtle.encrypt(
    { name: CRYPTO_ALGORITHMS.AES_GCM, iv },
    cryptoKey,
    data
  );

  log('Encryption successful, ciphertext length: %d', ciphertext.byteLength);

  return {
    ciphertext: new Uint8Array(ciphertext),
    iv,
  };
}

/**
 * Decrypt data with AES-GCM
 * @param {Uint8Array} ciphertext - Encrypted data
 * @param {Uint8Array} sk - Secret key (32 bytes)
 * @param {Uint8Array} iv - Initialization vector
 * @returns {Promise<Uint8Array>}
 */
export async function decryptWithAESGCM(ciphertext, sk, iv) {
  log('Decrypting data with AES-GCM');

  try {
    // Import secret key
    const cryptoKey = await crypto.subtle.importKey(
      'raw',
      sk,
      { name: CRYPTO_ALGORITHMS.AES_GCM, length: 256 },
      false,
      ['decrypt']
    );

    // Decrypt
    const plaintext = await crypto.subtle.decrypt(
      { name: CRYPTO_ALGORITHMS.AES_GCM, iv },
      cryptoKey,
      ciphertext
    );

    log('Decryption successful, plaintext length: %d', plaintext.byteLength);

    return new Uint8Array(plaintext);
  } catch (error) {
    log.error('Decryption failed: %s', error.message);
    throw new KeystoreEncryptionError(
      `Failed to decrypt data: ${error.message}`,
      { cause: error }
    );
  }
}

/**
 * Store secret key in WebAuthn credential using largeBlob extension
 *
 * Defaults to `support: 'required'` so an authenticator that cannot hold a
 * blob fails the ceremony outright. That is the safe default here: under
 * `'preferred'` the credential is created successfully and the secret is
 * simply never written, which loses the keystore silently.
 *
 * Pass `'preferred'` only when the caller reads the outcome back with
 * {@link extensionSupportFromCredential} and handles an unsupported
 * authenticator itself — probing for capability, for instance.
 *
 * @param {Object} credentialOptions - WebAuthn credential creation options
 * @param {Uint8Array} sk - Secret key to store
 * @param {'required'|'preferred'} [support] - largeBlob support level
 * @returns {Object} Enhanced credential options with largeBlob
 */
export function addLargeBlobToCredentialOptions(
  credentialOptions,
  sk,
  support = 'required'
) {
  log(
    'Adding largeBlob extension to credential options (support: %s)',
    support
  );

  return {
    ...credentialOptions,
    extensions: {
      ...credentialOptions.extensions,
      largeBlob: {
        support,
        write: sk,
      },
    },
  };
}

/**
 * Add PRF extension to credential options
 * @param {Object} credentialOptions - WebAuthn credential creation options
 * @param {Uint8Array} [prfInput] - Optional PRF input (salt)
 * @returns {{credentialOptions: Object, prfInput: Uint8Array}}
 */
export function addPRFToCredentialOptions(
  credentialOptions,
  prfInput = crypto.getRandomValues(new Uint8Array(32))
) {
  log('Adding PRF extension to credential options');

  return {
    credentialOptions: {
      ...credentialOptions,
      extensions: {
        ...credentialOptions.extensions,
        prf: {
          eval: { first: prfInput },
        },
      },
    },
    prfInput,
  };
}

/**
 * Write the secret key into the credential's largeBlob.
 *
 * A blob can only be written during an assertion, never at registration — so
 * this costs one extra WebAuthn prompt after the credential exists. That is
 * why `addLargeBlobToCredentialOptions()` alone does not persist anything.
 *
 * Throws unless the authenticator reports `written: true`. Silence here would
 * leave a keystore whose key exists only in memory: it works for the current
 * session and can never be unlocked again, because
 * {@link retrieveSKFromLargeBlob} would read a blob nobody wrote.
 *
 * @param {Uint8Array} credentialId - WebAuthn credential ID (raw bytes).
 * @param {Uint8Array} sk - Secret key to store.
 * @param {string} rpId - Relying party ID (domain).
 * @returns {Promise<void>}
 */
export async function writeSKToLargeBlob(credentialId, sk, rpId) {
  log('Writing secret key to largeBlob');

  let assertion;
  try {
    assertion = await navigator.credentials.get(
      buildCredentialRequestOptions({
        challenge: crypto.getRandomValues(new Uint8Array(32)),
        credentialId,
        rpId,
        userVerification: 'required',
        extensions: {
          largeBlob: {
            write: sk,
          },
        },
      })
    );
  } catch (error) {
    log.error('largeBlob write assertion failed: %s', error.message);
    throw new KeystoreEncryptionError(
      `Failed to write secret key to largeBlob: ${error.message}`,
      { cause: error }
    );
  }

  // The authenticator answers whether it took the blob. Accepting the
  // assertion without reading this is how a write that never happened passes
  // for a success.
  const written = assertion?.getClientExtensionResults?.()?.largeBlob?.written;

  if (written !== true) {
    log.error(
      'Authenticator did not write the largeBlob (written: %o)',
      written
    );
    throw new KeystoreEncryptionError(
      'Authenticator did not store the secret key in largeBlob'
    );
  }

  log('Secret key written to largeBlob');
}

/**
 * Retrieve secret key from WebAuthn credential using largeBlob extension
 * @param {Uint8Array} credentialId - WebAuthn credential ID
 * @param {string} rpId - Relying party ID (domain)
 * @returns {Promise<Uint8Array>} Secret key
 */
export async function retrieveSKFromLargeBlob(credentialId, rpId) {
  log('Retrieving secret key from largeBlob');

  try {
    const assertion = await navigator.credentials.get(
      buildCredentialRequestOptions({
        challenge: crypto.getRandomValues(new Uint8Array(32)),
        credentialId,
        rpId,
        userVerification: 'required',
        extensions: {
          largeBlob: {
            read: true,
          },
        },
      })
    );

    const extensions = assertion.getClientExtensionResults();

    if (!extensions.largeBlob || !extensions.largeBlob.blob) {
      throw new KeystoreEncryptionError(
        'No largeBlob data found in credential'
      );
    }

    const sk = new Uint8Array(extensions.largeBlob.blob);
    log('Retrieved secret key from largeBlob, length: %d', sk.length);

    return sk;
  } catch (error) {
    log.error(
      'Failed to retrieve secret key from largeBlob: %s',
      error.message
    );
    throw new KeystoreEncryptionError(
      `Failed to retrieve secret key: ${error.message}`,
      { cause: error }
    );
  }
}

/**
 * Add hmac-secret extension to credential options
 * @param {Object} credentialOptions - WebAuthn credential creation options
 * @returns {Object} Enhanced credential options with hmac-secret
 */
export function addHmacSecretToCredentialOptions(credentialOptions) {
  log('Adding hmac-secret extension to credential options');

  return {
    ...credentialOptions,
    extensions: {
      ...credentialOptions.extensions,
      hmacCreateSecret: true,
    },
  };
}

/**
 * Wrap secret key using hmac-secret extension
 * @param {Uint8Array} credentialId - WebAuthn credential ID
 * @param {Uint8Array} sk - Secret key to wrap
 * @param {string} rpId - Relying party ID (domain)
 * @returns {Promise<{wrappedSK: Uint8Array, salt: Uint8Array}>}
 */
export async function wrapSKWithHmacSecret(credentialId, sk, rpId) {
  log('Wrapping secret key with hmac-secret');

  const salt = crypto.getRandomValues(new Uint8Array(32));

  try {
    const assertion = await navigator.credentials.get(
      buildCredentialRequestOptions({
        challenge: crypto.getRandomValues(new Uint8Array(32)),
        credentialId,
        rpId,
        userVerification: 'required',
        extensions: {
          hmacGetSecret: {
            salt1: salt,
          },
        },
      })
    );

    const extensions = assertion.getClientExtensionResults();

    if (!extensions.hmacGetSecret || !extensions.hmacGetSecret.output1) {
      throw new KeystoreEncryptionError(
        'No hmac-secret output from credential'
      );
    }

    const hmacOutput = new Uint8Array(extensions.hmacGetSecret.output1);

    // Use HMAC output as wrapping key
    const wrappedSK = await encryptWithAESGCM(sk, hmacOutput.slice(0, 32));

    log('Secret key wrapped with hmac-secret');

    return {
      wrappedSK: wrappedSK.ciphertext,
      wrappingIV: wrappedSK.iv,
      salt,
    };
  } catch (error) {
    log.error('Failed to wrap secret key with hmac-secret: %s', error.message);
    throw new KeystoreEncryptionError(
      `Failed to wrap secret key: ${error.message}`,
      { cause: error }
    );
  }
}

/**
 * Wrap secret key using PRF extension
 * @param {Uint8Array} credentialId - WebAuthn credential ID
 * @param {Uint8Array} sk - Secret key to wrap
 * @param {string} rpId - Relying party ID (domain)
 * @param {Uint8Array} [prfInput] - PRF input (salt) for deterministic output
 * @returns {Promise<{wrappedSK: Uint8Array, wrappingIV: Uint8Array, salt: Uint8Array, prfSource: string}>}
 */
export async function wrapSKWithPRF(credentialId, sk, rpId, prfInput) {
  log('Wrapping secret key with PRF');

  const prfEval = prfInput || crypto.getRandomValues(new Uint8Array(32));

  try {
    const assertion = await navigator.credentials.get(
      buildCredentialRequestOptions({
        challenge: crypto.getRandomValues(new Uint8Array(32)),
        credentialId,
        rpId,
        userVerification: 'required',
        extensions: {
          prf: {
            eval: { first: prfEval },
          },
        },
      })
    );

    const { seed, source } = getPrfSeedOrThrow(assertion, 'wrapped');
    const prfKey = await deriveKeyFromPrfSeed(seed);
    const wrapped = await encryptWithAESGCM(sk, prfKey);

    log('Secret key wrapped with PRF (%s)', source);

    return {
      wrappedSK: wrapped.ciphertext,
      wrappingIV: wrapped.iv,
      salt: prfEval,
      prfSource: source,
    };
  } catch (error) {
    if (error instanceof PrfUnavailableError) throw error;
    log.error('Failed to wrap secret key with PRF: %s', error.message);
    throw new KeystoreEncryptionError(
      `Failed to wrap secret key: ${error.message}`,
      { cause: error }
    );
  }
}

/**
 * Unwrap secret key using hmac-secret extension
 * @param {Uint8Array} credentialId - WebAuthn credential ID
 * @param {Uint8Array} wrappedSK - Wrapped secret key
 * @param {Uint8Array} wrappingIV - IV used for wrapping
 * @param {Uint8Array} salt - Salt used for HMAC
 * @param {string} rpId - Relying party ID (domain)
 * @returns {Promise<Uint8Array>} Unwrapped secret key
 */
export async function unwrapSKWithHmacSecret(
  credentialId,
  wrappedSK,
  wrappingIV,
  salt,
  rpId
) {
  log('Unwrapping secret key with hmac-secret');

  try {
    const assertion = await navigator.credentials.get(
      buildCredentialRequestOptions({
        challenge: crypto.getRandomValues(new Uint8Array(32)),
        credentialId,
        rpId,
        userVerification: 'required',
        extensions: {
          hmacGetSecret: {
            salt1: salt,
          },
        },
      })
    );

    const extensions = assertion.getClientExtensionResults();

    if (!extensions.hmacGetSecret || !extensions.hmacGetSecret.output1) {
      throw new KeystoreEncryptionError(
        'No hmac-secret output from credential'
      );
    }

    const hmacOutput = new Uint8Array(extensions.hmacGetSecret.output1);

    // Unwrap with HMAC output
    const sk = await decryptWithAESGCM(
      wrappedSK,
      hmacOutput.slice(0, 32),
      wrappingIV
    );

    log('Secret key unwrapped with hmac-secret');

    return sk;
  } catch (error) {
    log.error(
      'Failed to unwrap secret key with hmac-secret: %s',
      error.message
    );
    throw new KeystoreEncryptionError(
      `Failed to unwrap secret key: ${error.message}`,
      { cause: error }
    );
  }
}

/**
 * Unwrap secret key using PRF extension
 * @param {Uint8Array} credentialId - WebAuthn credential ID
 * @param {Uint8Array} wrappedSK - Wrapped secret key
 * @param {Uint8Array} wrappingIV - IV used for wrapping
 * @param {Uint8Array} salt - PRF input (salt)
 * @param {string} rpId - Relying party ID (domain)
 * @returns {Promise<Uint8Array>} Unwrapped secret key
 */
export async function unwrapSKWithPRF(
  credentialId,
  wrappedSK,
  wrappingIV,
  salt,
  rpId
) {
  log('Unwrapping secret key with PRF');

  const prfEval = salt || crypto.getRandomValues(new Uint8Array(32));

  try {
    const assertion = await navigator.credentials.get(
      buildCredentialRequestOptions({
        challenge: crypto.getRandomValues(new Uint8Array(32)),
        credentialId,
        rpId,
        userVerification: 'required',
        extensions: {
          prf: {
            eval: { first: prfEval },
          },
        },
      })
    );

    const { seed, source } = getPrfSeedOrThrow(assertion, 'unwrapped');
    const prfKey = await deriveKeyFromPrfSeed(seed);
    const sk = await decryptWithAESGCM(wrappedSK, prfKey, wrappingIV);

    log('Secret key unwrapped with PRF (%s)', source);
    return sk;
  } catch (error) {
    if (error instanceof PrfUnavailableError) throw error;
    log.error('Failed to unwrap secret key with PRF: %s', error.message);
    throw new KeystoreEncryptionError(
      `Failed to unwrap secret key: ${error.message}`,
      { cause: error }
    );
  }
}

/**
 * Store encrypted keystore data in IndexedDB
 * @param {Object} data - Encrypted keystore data
 * @param {string} credentialId - WebAuthn credential ID (used as key)
 */
export async function storeEncryptedKeystore(data, credentialId) {
  log('Storing encrypted keystore in IndexedDB');

  const storageKey = `encrypted-keystore-${credentialId}`;

  const normalizeBytes = (value) => {
    if (!value) return null;
    if (value instanceof Uint8Array) return value;
    if (value instanceof ArrayBuffer) return new Uint8Array(value);
    if (ArrayBuffer.isView(value)) {
      return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    }
    if (Array.isArray(value)) return new Uint8Array(value);
    return null;
  };

  const serializePublicKey = (publicKey) => {
    if (!publicKey) return undefined;
    const bytes = normalizeBytes(publicKey);
    if (bytes) {
      return {
        __type: 'uint8array',
        bytes: Array.from(bytes),
      };
    }
    return {
      ...publicKey,
      x: publicKey.x ? Array.from(publicKey.x) : undefined,
      y: publicKey.y ? Array.from(publicKey.y) : undefined,
    };
  };

  const serializedData = {
    ciphertext: Array.from(data.ciphertext),
    iv: Array.from(data.iv),
    credentialId: data.credentialId,
    publicKey: serializePublicKey(data.publicKey),
    wrappedSK: data.wrappedSK ? Array.from(data.wrappedSK) : undefined,
    wrappingIV: data.wrappingIV ? Array.from(data.wrappingIV) : undefined,
    salt: data.salt ? Array.from(data.salt) : undefined,
    encryptionMethod:
      data.encryptionMethod || KEYSTORE_ENCRYPTION_METHODS.LARGE_BLOB,
    keyType: data.keyType,
    timestamp: Date.now(),
  };

  try {
    localStorage.setItem(storageKey, JSON.stringify(serializedData));
    log('Encrypted keystore stored successfully');
  } catch (error) {
    log.error('Failed to store encrypted keystore: %s', error.message);
    throw new KeystoreEncryptionError(
      `Failed to store encrypted keystore: ${error.message}`,
      { cause: error }
    );
  }
}

/**
 * Load encrypted keystore data from IndexedDB
 * @param {string} credentialId - WebAuthn credential ID
 * @returns {Promise<Object>} Encrypted keystore data
 */
export async function loadEncryptedKeystore(credentialId) {
  log('Loading encrypted keystore from IndexedDB');

  const storageKey = `encrypted-keystore-${credentialId}`;

  try {
    const stored = localStorage.getItem(storageKey);

    if (!stored) {
      throw new KeystoreEncryptionError(
        'No encrypted keystore found for this credential'
      );
    }

    const data = JSON.parse(stored);

    const deserializePublicKey = (publicKey) => {
      if (!publicKey) return undefined;
      if (publicKey.__type === 'uint8array') {
        return new Uint8Array(publicKey.bytes || []);
      }
      return {
        ...publicKey,
        x: publicKey.x ? new Uint8Array(publicKey.x) : undefined,
        y: publicKey.y ? new Uint8Array(publicKey.y) : undefined,
      };
    };

    const deserialized = {
      ciphertext: new Uint8Array(data.ciphertext),
      iv: new Uint8Array(data.iv),
      credentialId: data.credentialId,
      publicKey: deserializePublicKey(data.publicKey),
      wrappedSK: data.wrappedSK ? new Uint8Array(data.wrappedSK) : undefined,
      wrappingIV: data.wrappingIV ? new Uint8Array(data.wrappingIV) : undefined,
      salt: data.salt ? new Uint8Array(data.salt) : undefined,
      encryptionMethod:
        data.encryptionMethod || KEYSTORE_ENCRYPTION_METHODS.LARGE_BLOB,
      keyType: data.keyType,
      timestamp: data.timestamp,
    };

    log('Encrypted keystore loaded successfully');

    return deserialized;
  } catch (error) {
    log.error('Failed to load encrypted keystore: %s', error.message);
    throw new KeystoreEncryptionError(
      `Failed to load encrypted keystore: ${error.message}`,
      { cause: error }
    );
  }
}

/**
 * Clear encrypted keystore from storage
 * @param {string} credentialId - WebAuthn credential ID
 */
export async function clearEncryptedKeystore(credentialId) {
  log('Clearing encrypted keystore from storage');

  const storageKey = `encrypted-keystore-${credentialId}`;

  try {
    localStorage.removeItem(storageKey);
    log('Encrypted keystore cleared successfully');
  } catch (error) {
    log.error('Failed to clear encrypted keystore: %s', error.message);
  }
}

/**
 * Which WebAuthn extensions is this *client* willing to negotiate?
 *
 * Answers one question only: would the browser pass the extension through. It
 * cannot tell you whether the authenticator behind it will honour the request —
 * that is settled during a ceremony, by
 * {@link extensionSupportFromCredential}, and belongs to the credential rather
 * than to the browser.
 *
 * `known: false` means the browser is too old to say. That is **not** the same
 * as unsupported: callers should attempt the ceremony and let its result
 * decide, rather than disabling the feature outright.
 *
 * @returns {Promise<{largeBlob: boolean, prf: boolean, hmacSecret: boolean, known: boolean}>}
 */
export async function checkExtensionSupport() {
  const support = {
    largeBlob: false,
    prf: false,
    hmacSecret: false,
    known: false,
  };

  if (typeof globalThis.PublicKeyCredential !== 'function') {
    return support;
  }

  // getClientCapabilities is the only pre-flight answer that means anything.
  // The previous check asked `'largeBlob' in PublicKeyCredential.prototype`,
  // which tests whether the extension is a property of the credential
  // interface. Extensions never are — they arrive through
  // getClientExtensionResults() — so it returned false in every browser ever
  // shipped, including those with complete support, and silently disabled
  // keystore encryption everywhere.
  if (typeof PublicKeyCredential.getClientCapabilities !== 'function') {
    log('getClientCapabilities unavailable; extension support is unknown');
    return support;
  }

  try {
    const capabilities = await PublicKeyCredential.getClientCapabilities();
    return {
      largeBlob: capabilities['extension:largeBlob'] === true,
      prf: capabilities['extension:prf'] === true,
      hmacSecret: capabilities['extension:hmacCreateSecret'] === true,
      known: true,
    };
  } catch (error) {
    log.error('Failed to check extension support: %s', error.message);
    return support;
  }
}

/**
 * What did the authenticator actually agree to, for this credential?
 *
 * The authoritative answer, and the only one worth persisting: a browser may
 * support largeBlob while the security key in front of it does not. Read this
 * from the registration response and store it next to the credential.
 *
 * Requires the ceremony to have asked with `support: 'preferred'` — see
 * {@link addLargeBlobToCredentialOptions}. Asking with `'required'` makes
 * creation fail outright instead of reporting back.
 *
 * @param {PublicKeyCredential} credential - The result of navigator.credentials.create().
 * @returns {{largeBlob: boolean, prf: boolean, hmacSecret: boolean}}
 */
export function extensionSupportFromCredential(credential) {
  const support = { largeBlob: false, prf: false, hmacSecret: false };

  if (typeof credential?.getClientExtensionResults !== 'function') {
    return support;
  }

  try {
    const results = credential.getClientExtensionResults() ?? {};
    return {
      largeBlob: results.largeBlob?.supported === true,
      // PRF reports either an explicit `enabled` flag or, when the ceremony
      // evaluated a salt straight away, the results themselves.
      prf: results.prf?.enabled === true || results.prf?.results != null,
      hmacSecret: results.hmacCreateSecret === true,
    };
  } catch (error) {
    log.error(
      'Failed to read extension results from credential: %s',
      error.message
    );
    return support;
  }
}

export default {
  generateSecretKey,
  encryptWithAESGCM,
  decryptWithAESGCM,
  addLargeBlobToCredentialOptions,
  writeSKToLargeBlob,
  retrieveSKFromLargeBlob,
  addHmacSecretToCredentialOptions,
  wrapSKWithHmacSecret,
  unwrapSKWithHmacSecret,
  storeEncryptedKeystore,
  loadEncryptedKeystore,
  clearEncryptedKeystore,
  checkExtensionSupport,
  extensionSupportFromCredential,
};

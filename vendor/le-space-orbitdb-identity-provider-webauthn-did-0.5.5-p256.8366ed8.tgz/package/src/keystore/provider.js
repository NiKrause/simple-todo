/**
 * OrbitDB Identity Provider for WebAuthn + Keystore
 */

import { logger } from '@libp2p/logger';
import { generateKeyPair } from '@libp2p/crypto/keys';
import { varint } from 'multiformats';
import { base58btc } from 'multiformats/bases/base58';
import * as KeystoreEncryption from './encryption.js';
import { ensureDerivedSigningKey } from './derived-signing-key.js';
import { assertSigner, isSessionKeystore } from './session-keystore.js';
import { PrfUnavailableError } from '../errors.js';
import { WebAuthnDIDProvider } from '../webauthn/provider.js';
import { verifyWebAuthnIdentityBinding } from '../webauthn/proof-verification.js';
import {
  identityProofKey,
  loadIdentityProof,
  storeIdentityProof,
} from '../webauthn/identity-proof-store.js';
import {
  DID_KEY_PREFIX,
  IDENTITY_TYPES,
  KEYSTORE_ENCRYPTION_METHODS,
  KEY_TYPES,
} from '../constants.js';

const identityLog = logger('orbitdb-identity-provider-webauthn-did:identity');

function normalizeByteArray(value) {
  if (!value) return new Uint8Array(0);
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (ArrayBuffer.isView(value)) {
    return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
  }
  if (Array.isArray(value)) return new Uint8Array(value);
  if (typeof value === 'object' && typeof value.length === 'number') {
    return new Uint8Array(value);
  }
  return new Uint8Array(0);
}

/**
 * OrbitDB Identity Provider that uses WebAuthn
 */
export class OrbitDBWebAuthnIdentityProvider {
  /**
   * @param {Object} options - Provider configuration.
   * @param {Object} options.webauthnCredential - WebAuthn credential info.
   * @param {boolean} [options.useKeystoreDID=false] - Use keystore DID instead of WebAuthn DID.
   * @param {Object|null} [options.keystore=null] - OrbitDB keystore instance.
   * @param {string} [options.keystoreKeyType='secp256k1'] - Keystore key type.
   * @param {boolean} [options.encryptKeystore=false] - Encrypt keystore at rest.
   * @param {string} [options.keystoreEncryptionMethod='prf'] - Encryption method.
   * @param {boolean} [options.deriveSigningKeyFromPrf=true] - Derive the OrbitDB
   *   signing key from the passkey's PRF output instead of a random one.
   * @param {string} [options.signingKeyType='secp256k1'] - Type of that derived
   *   key: 'secp256k1' or 'Ed25519'. `useKeystoreDID` has its own
   *   `keystoreKeyType`.
   * @param {Object} [options.signer] - A key that signs elsewhere (see
   *   `createWorkerSigner`): the identity is its DID, OrbitDB signs through
   *   it, and nothing of it is in this provider or any keystore. Give
   *   `Identities()` the keystore from `createSessionKeystore({ signer })`.
   */
  constructor({
    webauthnCredential,
    useKeystoreDID = false,
    keystore = null,
    keystoreKeyType = KEY_TYPES.SECP256K1,
    encryptKeystore = false,
    keystoreEncryptionMethod = KEYSTORE_ENCRYPTION_METHODS.PRF,
    deriveSigningKeyFromPrf = true,
    signingKeyType = KEY_TYPES.SECP256K1,
    signer = null,
  }) {
    if (signer) assertSigner(signer);
    this.signer = signer;
    if (![KEY_TYPES.SECP256K1, KEY_TYPES.ED25519].includes(signingKeyType)) {
      throw new Error(
        `signingKeyType must be '${KEY_TYPES.SECP256K1}' or '${KEY_TYPES.ED25519}', not '${signingKeyType}'`
      );
    }
    this.credential = webauthnCredential;
    this.signingKeyType = signingKeyType;
    // Costs one extra assertion the first time an identity is created on a
    // device. Set false to keep a keystore-generated key instead.
    this.deriveSigningKeyFromPrf = deriveSigningKeyFromPrf;
    this.webauthnProvider = new WebAuthnDIDProvider(webauthnCredential);
    this.type = IDENTITY_TYPES.WEBAUTHN; // Set instance property
    this.useKeystoreDID = useKeystoreDID; // Flag to use Ed25519 DID from keystore
    this.keystore = keystore; // OrbitDB keystore instance
    this.keystoreKeyType = keystoreKeyType; // Key type: 'secp256k1' or 'Ed25519'
    this.encryptKeystore = encryptKeystore; // Flag to encrypt keystore
    this.keystoreEncryptionMethod = keystoreEncryptionMethod; // Encryption method
    this.unlockedKeypair = null; // Store unlocked keypair during session
    /**
     * What actually happened to `encryptKeystore`, for the app to show.
     * `{ enabled: true, method }` once the keystore is sealed, or
     * `{ enabled: false, reason }` — `'not-requested'`, or `'prf-unavailable'`
     * when the authenticator has no PRF and the key therefore went into the
     * keystore unencrypted rather than "encrypted" under a public value.
     */
    this.encryptionState = signer
      ? { enabled: false, reason: 'external-signer' }
      : encryptKeystore
        ? { enabled: true, method: keystoreEncryptionMethod }
        : { enabled: false, reason: 'not-requested' };
    this.warnedAboutPersistence = false;
  }

  static get type() {
    return IDENTITY_TYPES.WEBAUTHN;
  }

  /**
   * Resolve the identity DID.
   *
   * OrbitDB passes its own keystore in `options` and calls this before
   * `keystore.getKey(id)`, which is the only window in which the signing key
   * can be seeded deterministically. See derived-signing-key.js.
   *
   * @param {Object} [options] - Options supplied by OrbitDB.
   * @returns {Promise<string>} DID string.
   */
  async getId(options = {}) {
    identityLog('getId() called');

    // An external signer is the identity: its DID names its key, and the
    // keystore OrbitDB holds answers for that DID with something that signs
    // through it. Verification is the keystore-DID rule — the DID's key must
    // equal `publicKey` — which this satisfies by construction.
    if (this.signer) {
      const keystore = options.keystore ?? this.keystore;
      if (keystore && !(await keystore.getKey(this.signer.did))) {
        throw new Error(
          'the keystore does not serve the signer; create it with createSessionKeystore({ signer })'
        );
      }
      return this.signer.did;
    }

    // If useKeystoreDID flag is set, create Ed25519 DID from keystore
    if (this.useKeystoreDID && this.keystore) {
      if (this.encryptKeystore) {
        await this.ensureEncryptedKeystore();
      }
      identityLog('Using Ed25519 DID from keystore');
      const did = await this.createEd25519DIDFromKeystore();
      identityLog(
        'getId() returning Ed25519 DID: %s',
        did.substring(0, 32) + '...'
      );
      return did;
    }

    // Default: Return P-256 DID from WebAuthn credential
    const did = await WebAuthnDIDProvider.createDID(this.credential);

    // Seed the signing key before OrbitDB reaches for it. Never fatal: without
    // PRF the keystore generates its own key and the identity stays stable per
    // device, just not reproducible across them.
    if (this.deriveSigningKeyFromPrf !== false) {
      const keystore = options.keystore ?? this.keystore;
      if (keystore) {
        const outcome = await ensureDerivedSigningKey({
          keystore,
          did,
          credential: this.credential,
          keyType: this.signingKeyType,
        });
        identityLog('Derived signing key: %s', outcome);
      }
    }

    identityLog(
      'getId() returning P-256 DID: %s',
      did.substring(0, 32) + '...'
    );
    return did;
  }

  async ensureEncryptedKeystore() {
    if (this.unlockedKeypair) {
      return;
    }

    try {
      await KeystoreEncryption.loadEncryptedKeystore(
        this.credential.credentialId
      );
    } catch (error) {
      identityLog(
        'Encrypted keystore missing, creating a new one: %s',
        error.message
      );
      try {
        await this.createEncryptedKeystore();
      } catch (createError) {
        if (!(createError instanceof PrfUnavailableError)) throw createError;
        // No PRF, no secret to wrap with. Carry on unencrypted and say so,
        // instead of sealing the key under the credential id as before.
        this.encryptKeystore = false;
        this.encryptionState = { enabled: false, reason: 'prf-unavailable' };
        console.warn(
          '[orbitdb-identity-provider-webauthn-did] encryptKeystore: this authenticator has no PRF, so the keystore key is NOT encrypted at rest. See provider.encryptionState.'
        );
        return;
      }
      // Creating it left the pair in memory; unlocking again would only cost
      // another prompt.
      if (this.unlockedKeypair) return;
    }

    await this.unlockEncryptedKeystore();
  }

  /**
   * Create Ed25519 DID from OrbitDB keystore
   * This uses the keystore's Ed25519 key to create a did:key DID
   */
  async createEd25519DIDFromKeystore() {
    if (!this.keystore) {
      throw new Error('Keystore is required to create Ed25519 DID');
    }

    try {
      if (this.encryptKeystore) {
        const encryptedData = this.unlockedKeypair
          ? {
              publicKey: this.unlockedKeypair.publicKey,
              keyType: this.unlockedKeypair.keyType,
            }
          : await KeystoreEncryption.loadEncryptedKeystore(
              this.credential.credentialId
            );
        const publicKeyBytes = normalizeByteArray(encryptedData.publicKey);
        const keyType = encryptedData.keyType || this.keystoreKeyType;

        const did = this.createDIDFromKeystorePublicKey(
          publicKeyBytes,
          keyType,
          varint,
          base58btc
        );
        // OrbitDB signs with whatever key it finds under the id, and creates a
        // secp256k1 one when there is none — so without this the DID said
        // Ed25519 and the entries were signed by an unrelated key.
        if (
          this.unlockedKeypair?.privateKey &&
          !(await this.keystore.getKey(did))
        ) {
          // OrbitDB's default keystore writes this to disk in clear, and then
          // the encrypted copy protects nothing. The app has to hand OrbitDB
          // a keystore that forgets — createSessionKeystore() — and this is
          // the one place that can tell whether it did.
          if (
            !isSessionKeystore(this.keystore) &&
            !this.warnedAboutPersistence
          ) {
            this.warnedAboutPersistence = true;
            console.warn(
              '[orbitdb-identity-provider-webauthn-did] encryptKeystore: the OrbitDB keystore persists the unlocked key unencrypted. Pass `keystore: await createSessionKeystore()` to Identities() so it stays in memory.'
            );
          }
          await this.keystore.addKey(did, {
            privateKey: this.unlockedKeypair.privateKey,
          });
        }
        return did;
      }

      // Get the keystore's identity ID (this will be used to retrieve the key)
      // We'll use the WebAuthn DID as the identity ID to get/create the keystore key
      const identityId = await WebAuthnDIDProvider.createDID(this.credential);

      // Get or create the Ed25519 key from keystore
      // Try getKey first, if it doesn't exist, createKey will create it
      let keystoreKey = await this.keystore.getKey(identityId);
      if (!keystoreKey) {
        identityLog(
          'Key not found, creating new key for: %s with type: %s',
          identityId.substring(0, 32) + '...',
          this.keystoreKeyType
        );
        const keyType =
          this.keystoreKeyType === KEY_TYPES.SECP256K1
            ? KEY_TYPES.SECP256K1
            : KEY_TYPES.ED25519;
        keystoreKey = await generateKeyPair(keyType);
        await this.keystore.addKey(identityId, {
          privateKey: keystoreKey.raw,
        });
      }

      identityLog(
        'Keystore key obtained, type: %s, keys: %o',
        typeof keystoreKey,
        Object.keys(keystoreKey || {})
      );

      // The keystore key should have a public property with marshal method
      // But it seems this isn't available immediately after creation
      // Let's try to extract the public key bytes directly
      let publicKeyBytes;

      // Extract public key bytes from the keystore key
      // OrbitDB uses @libp2p/crypto keys which have different structures
      if (keystoreKey && keystoreKey.publicKey) {
        // Modern libp2p-crypto format - has publicKey property
        const pubKey = keystoreKey.publicKey;
        identityLog(
          'Found publicKey property, type: %s',
          pubKey.constructor.name
        );

        // Try to get raw bytes from the public key
        if (pubKey.raw) {
          publicKeyBytes = pubKey.raw;
          identityLog(
            'Got public key from publicKey.raw: %d bytes',
            publicKeyBytes.length
          );
        } else if (pubKey.bytes) {
          publicKeyBytes = pubKey.bytes;
          identityLog(
            'Got public key from publicKey.bytes: %d bytes',
            publicKeyBytes.length
          );
        } else if (typeof pubKey.marshal === 'function') {
          publicKeyBytes = pubKey.marshal();
          identityLog(
            'Got public key from publicKey.marshal(): %d bytes',
            publicKeyBytes.length
          );
        } else {
          identityLog.error('Cannot extract bytes from publicKey: %o', pubKey);
          throw new Error('Unable to extract bytes from publicKey');
        }
      } else if (
        keystoreKey &&
        keystoreKey.public &&
        keystoreKey.public.bytes
      ) {
        // Older libp2p-crypto format
        publicKeyBytes = keystoreKey.public.bytes;
        identityLog(
          'Got public key from keystoreKey.public.bytes: %d bytes',
          publicKeyBytes.length
        );
      } else if (keystoreKey && keystoreKey.bytes) {
        // Direct bytes
        publicKeyBytes = keystoreKey.bytes;
        identityLog(
          'Got public key from keystoreKey.bytes: %d bytes',
          publicKeyBytes.length
        );
      } else {
        identityLog.error(
          'Cannot extract public key from keystoreKey: %o',
          keystoreKey
        );
        throw new Error('Unable to extract public key from keystore key');
      }

      // Note: secp256k1 public keys are 33 or 65 bytes (compressed/uncompressed)
      // Ed25519 public keys are 32 bytes
      // We need to handle both
      identityLog(
        'Public key extracted: %d bytes, key type: %s',
        publicKeyBytes.length,
        keystoreKey.type
      );

      if (!publicKeyBytes || publicKeyBytes.length < 32) {
        throw new Error(
          `Invalid public key length: ${publicKeyBytes ? publicKeyBytes.length : 0} bytes`
        );
      }

      identityLog(
        'Successfully extracted public key: %d bytes, type: %s',
        publicKeyBytes.length,
        keystoreKey.type
      );

      const did = this.createDIDFromKeystorePublicKey(
        publicKeyBytes,
        keystoreKey.type,
        varint,
        base58btc
      );
      // Stored above under the credential's P-256 DID; OrbitDB looks it up under
      // the DID returned here, found nothing, and generated a secp256k1 key.
      if (!(await this.keystore.getKey(did))) {
        await this.keystore.addKey(did, { privateKey: keystoreKey.raw });
      }
      return did;
    } catch (error) {
      identityLog.error(
        'Failed to create Ed25519 DID from keystore: %s',
        error.message
      );
      throw new Error(
        `Failed to create Ed25519 DID from keystore: ${error.message}`
      );
    }
  }

  createDIDFromKeystorePublicKey(publicKeyBytes, keyType, varint, base58btc) {
    // Determine the correct multicodec based on key type
    // secp256k1 multicodec code (0xe7) or Ed25519 (0xed)
    let multicodec;
    if (keyType === KEY_TYPES.SECP256K1) {
      multicodec = 0xe7; // secp256k1-pub
      identityLog('Using secp256k1 multicodec (0xe7)');
    } else if (keyType === KEY_TYPES.ED25519 || keyType === 'ed25519') {
      multicodec = 0xed; // ed25519-pub
      identityLog('Using Ed25519 multicodec (0xed)');
    } else {
      throw new Error(`Unsupported key type: ${keyType}`);
    }

    const codecLength = varint.encodingLength(multicodec);
    const codecBytes = new Uint8Array(codecLength);
    varint.encodeTo(multicodec, codecBytes, 0);

    if (codecBytes.length === 0) {
      throw new Error('Failed to encode ED25519_MULTICODEC with varint');
    }

    // Combine multicodec prefix + public key bytes
    const multikey = new Uint8Array(codecBytes.length + publicKeyBytes.length);
    multikey.set(codecBytes, 0);
    multikey.set(publicKeyBytes, codecBytes.length);

    // Encode as base58btc and create did:key
    const multikeyEncoded = base58btc.encode(multikey);
    return `${DID_KEY_PREFIX}${multikeyEncoded}`;
  }

  /**
   * Create and encrypt OrbitDB keystore
   * @returns {Promise<void>}
   */
  async createEncryptedKeystore() {
    if (!this.encryptKeystore) {
      identityLog('ℹ️ Keystore encryption not enabled, skipping');
      return;
    }

    identityLog(
      '🔐 Creating encrypted keystore with method:',
      this.keystoreEncryptionMethod
    );
    identityLog(
      'Creating encrypted keystore with method: %s',
      this.keystoreEncryptionMethod
    );

    try {
      // Generate secret key
      const sk = KeystoreEncryption.generateSecretKey();

      const keyType =
        this.keystoreKeyType === KEY_TYPES.SECP256K1
          ? KEY_TYPES.SECP256K1
          : KEY_TYPES.ED25519;
      const keyPair = await generateKeyPair(keyType);
      const privateKeyBytes = keyPair.marshal ? keyPair.marshal() : keyPair.raw;
      const publicKeyBytes = keyPair.publicKey?.marshal
        ? keyPair.publicKey.marshal()
        : keyPair.publicKey?.raw;

      if (!privateKeyBytes || !publicKeyBytes) {
        throw new Error('Failed to serialize keystore keypair');
      }
      const { ciphertext, iv } = await KeystoreEncryption.encryptWithAESGCM(
        privateKeyBytes,
        sk
      );

      // Store SK in WebAuthn or wrap it
      let encryptedData;

      if (this.keystoreEncryptionMethod === KEYSTORE_ENCRYPTION_METHODS.PRF) {
        // Wrap SK with PRF (WebAuthn Level 3 - preferred method)
        const wrapped = await KeystoreEncryption.wrapSKWithPRF(
          this.credential.rawCredentialId,
          sk,
          window.location.hostname
        );

        encryptedData = {
          ciphertext,
          iv,
          credentialId: this.credential.credentialId,
          publicKey: publicKeyBytes,
          keyType,
          wrappedSK: wrapped.wrappedSK,
          wrappingIV: wrapped.wrappingIV,
          salt: wrapped.salt,
          encryptionMethod: KEYSTORE_ENCRYPTION_METHODS.PRF,
        };
      } else if (
        this.keystoreEncryptionMethod === KEYSTORE_ENCRYPTION_METHODS.LARGE_BLOB
      ) {
        // Write the key into the authenticator before recording anything.
        // This used to be `secretKey: sk, // Will be moved to largeBlob` — and
        // nothing ever moved it: the field was dropped at serialization, so
        // the key survived only in memory and the keystore could never be
        // unlocked again. Throws if the authenticator refuses, which is better
        // than persisting a record that cannot be opened.
        await KeystoreEncryption.writeSKToLargeBlob(
          this.credential.rawCredentialId,
          sk,
          window.location.hostname
        );

        encryptedData = {
          ciphertext,
          iv,
          credentialId: this.credential.credentialId,
          publicKey: publicKeyBytes,
          keyType,
          encryptionMethod: KEYSTORE_ENCRYPTION_METHODS.LARGE_BLOB,
        };
      } else if (
        this.keystoreEncryptionMethod ===
        KEYSTORE_ENCRYPTION_METHODS.HMAC_SECRET
      ) {
        // Wrap SK with hmac-secret
        const wrapped = await KeystoreEncryption.wrapSKWithHmacSecret(
          this.credential.rawCredentialId,
          sk,
          window.location.hostname
        );

        encryptedData = {
          ciphertext,
          iv,
          credentialId: this.credential.credentialId,
          publicKey: publicKeyBytes,
          keyType,
          wrappedSK: wrapped.wrappedSK,
          wrappingIV: wrapped.wrappingIV,
          salt: wrapped.salt,
          encryptionMethod: KEYSTORE_ENCRYPTION_METHODS.HMAC_SECRET,
        };
      }

      // Store encrypted keystore
      identityLog(
        '💾 Storing encrypted keystore with credentialId:',
        this.credential.credentialId?.substring(0, 16) + '...'
      );
      await KeystoreEncryption.storeEncryptedKeystore(
        encryptedData,
        this.credential.credentialId
      );
      this.unlockedKeypair = {
        privateKey: privateKeyBytes,
        publicKey: publicKeyBytes,
        keyType,
      };
      identityLog('✅ Encrypted keystore stored successfully');
      this.unlockedKeypair = {
        privateKey: privateKeyBytes,
        publicKey: publicKeyBytes,
        keyType,
      };

      identityLog('Encrypted keystore created and stored successfully');
    } catch (error) {
      if (error instanceof PrfUnavailableError) throw error;
      identityLog.error(
        'Failed to create encrypted keystore: %s',
        error.message
      );
      throw new Error(`Failed to create encrypted keystore: ${error.message}`);
    }
  }

  /**
   * Unlock encrypted keystore
   * @returns {Promise<Object>} Decrypted keypair
   */
  async unlockEncryptedKeystore() {
    if (!this.encryptKeystore) {
      return null;
    }

    identityLog(
      'Unlocking encrypted keystore with method: %s',
      this.keystoreEncryptionMethod
    );

    try {
      // Load encrypted keystore
      const encryptedData = await KeystoreEncryption.loadEncryptedKeystore(
        this.credential.credentialId
      );

      let sk;

      if (encryptedData.encryptionMethod === KEYSTORE_ENCRYPTION_METHODS.PRF) {
        // Unwrap SK with PRF
        sk = await KeystoreEncryption.unwrapSKWithPRF(
          this.credential.rawCredentialId,
          encryptedData.wrappedSK,
          encryptedData.wrappingIV,
          encryptedData.salt,
          window.location.hostname
        );
      } else if (
        encryptedData.encryptionMethod ===
        KEYSTORE_ENCRYPTION_METHODS.LARGE_BLOB
      ) {
        // Retrieve SK from largeBlob
        sk = await KeystoreEncryption.retrieveSKFromLargeBlob(
          this.credential.rawCredentialId,
          window.location.hostname
        );
      } else if (
        encryptedData.encryptionMethod ===
        KEYSTORE_ENCRYPTION_METHODS.HMAC_SECRET
      ) {
        // Unwrap SK with hmac-secret
        sk = await KeystoreEncryption.unwrapSKWithHmacSecret(
          this.credential.rawCredentialId,
          encryptedData.wrappedSK,
          encryptedData.wrappingIV,
          encryptedData.salt,
          window.location.hostname
        );
      }

      // Decrypt keystore private key
      const privateKeyBytes = await KeystoreEncryption.decryptWithAESGCM(
        encryptedData.ciphertext,
        sk,
        encryptedData.iv
      );

      const publicKeyBytes = normalizeByteArray(encryptedData.publicKey);
      // Store unlocked keypair in memory for session
      this.unlockedKeypair = {
        privateKey: privateKeyBytes,
        publicKey: publicKeyBytes,
        keyType: encryptedData.keyType || this.keystoreKeyType,
      };

      identityLog('Encrypted keystore unlocked successfully');

      return this.unlockedKeypair;
    } catch (error) {
      identityLog.error(
        'Failed to unlock encrypted keystore: %s',
        error.message
      );
      throw new Error(`Failed to unlock encrypted keystore: ${error.message}`);
    }
  }

  /**
   * Sign data for OrbitDB identity operations.
   *
   * The result becomes `signatures.publicKey` in the identity document, which
   * OrbitDB content-addresses. A fresh WebAuthn assertion here would change
   * the document hash on every page load, and peers reject entries signed
   * under any document but the first one they verified (issue #18). The proof
   * is therefore stored under the payload it covers and reused; the assertion
   * happens once, when the identity is first established.
   *
   * @param {string|Uint8Array} data - Payload to sign.
   * @returns {Promise<string>} Signature envelope.
   */
  async signIdentity(data) {
    const dataLength = typeof data === 'string' ? data.length : data.byteLength;
    identityLog('signIdentity() called with data length: %d', dataLength);
    identityLog('Signer context: %o', {
      useKeystoreDID: this.useKeystoreDID,
      encryptKeystore: this.encryptKeystore,
      keystoreEncryptionMethod: this.keystoreEncryptionMethod,
      hasKeystore: Boolean(this.keystore),
      hasUnlockedKeypair: Boolean(this.unlockedKeypair),
    });

    if (this.signer) {
      // The document is self-signed by the same key that signs entries: no
      // WebAuthn prompt, and nothing the verifier reads for a keystore DID.
      const bytes =
        typeof data === 'string' ? new TextEncoder().encode(data) : data;
      const signature = await this.signer.sign(bytes);
      return Array.from(signature, (b) => b.toString(16).padStart(2, '0')).join(
        ''
      );
    }

    if (this.encryptKeystore && this.unlockedKeypair) {
      identityLog(
        'Encrypted keystore is unlocked, but signing currently remains WebAuthn-based'
      );
    }

    const proofKey = await identityProofKey(this.credential.credentialId, data);
    const stored = loadIdentityProof(proofKey);
    if (stored) {
      identityLog(
        'Reusing stored identity proof, so the identity document stays stable'
      );
      return stored;
    }

    identityLog('No stored identity proof; requesting a WebAuthn assertion');
    const proof = await this.webauthnProvider.sign(data);
    storeIdentityProof(proofKey, proof);
    return proof;
  }

  /**
   * Verify identity signature.
   * @param {string} signature - Signature envelope.
   * @param {string|Uint8Array} data - Payload that was signed.
   * @param {Object} [publicKey] - Optional public key override.
   * @returns {Promise<boolean>} True if valid.
   */
  verifyIdentity(signature, data, publicKey) {
    identityLog('verifyIdentity() called');
    return this.webauthnProvider.verify(
      signature,
      data,
      publicKey || this.credential.publicKey
    );
  }

  /**
   * Create OrbitDB identity using WebAuthn
   * @param {Object} options - Provider options.
   * @returns {Promise<Object>} OrbitDB identity object.
   */
  static async createIdentity(options) {
    const {
      webauthnCredential,
      useKeystoreDID = false,
      keystore = null,
      keystoreKeyType = KEY_TYPES.SECP256K1,
      encryptKeystore = false,
      keystoreEncryptionMethod = KEYSTORE_ENCRYPTION_METHODS.PRF,
      deriveSigningKeyFromPrf = true,
      signingKeyType = KEY_TYPES.SECP256K1,
      signer = null,
    } = options;

    identityLog(
      'createIdentity() called with useKeystoreDID: %s, keystoreKeyType: %s, encryptKeystore: %s',
      useKeystoreDID,
      keystoreKeyType,
      encryptKeystore
    );

    const provider = new OrbitDBWebAuthnIdentityProvider({
      webauthnCredential,
      useKeystoreDID,
      keystore,
      keystoreKeyType,
      encryptKeystore,
      keystoreEncryptionMethod,
      deriveSigningKeyFromPrf,
      signingKeyType,
      signer,
    });

    // If encryption is enabled, create and unlock encrypted keystore
    if (encryptKeystore && keystore) {
      try {
        identityLog(
          '🔐 Creating encrypted keystore with',
          keystoreEncryptionMethod,
          '...'
        );
        // Loads and unlocks an existing one; only creates when there is none.
        // This used to create unconditionally, replacing the sealed key on
        // every call.
        await provider.ensureEncryptedKeystore();
        identityLog('✅ Encrypted keystore created and unlocked successfully');
        identityLog('Encrypted keystore created and unlocked');
      } catch (error) {
        // Log error visibly so users know encryption failed
        console.error('❌ Failed to setup encrypted keystore:', error.message);
        console.error('   Full error:', error);
        identityLog.error(
          'Failed to setup encrypted keystore: %s',
          error.message
        );
        // Continue anyway - encryption is optional but user should know it failed
      }
    }

    const id = await provider.getId();

    identityLog('Identity created successfully: %o', {
      id: id.substring(0, 32) + '...',
      type: IDENTITY_TYPES.WEBAUTHN,
      didType: useKeystoreDID
        ? 'Ed25519 (from keystore)'
        : 'P-256 (from WebAuthn)',
      encrypted: encryptKeystore,
      hasPublicKey: !!webauthnCredential.publicKey,
    });

    return {
      id,
      publicKey: webauthnCredential.publicKey,
      type: IDENTITY_TYPES.WEBAUTHN,
      sign: (identity, data) => {
        identityLog('identity.sign() called from OrbitDB');
        return provider.signIdentity(data);
      },
      verify: (signature, data) => {
        identityLog('identity.verify() called from OrbitDB');
        return provider.verifyIdentity(
          signature,
          data,
          webauthnCredential.publicKey
        );
      },
    };
  }
}

/**
 * WebAuthn Identity Provider Function for OrbitDB
 * This follows the same pattern as OrbitDBIdentityProviderDID
 * Returns a function that returns a promise resolving to the provider instance
 *
 * @param {Object} options - Configuration options
 * @param {Object} options.webauthnCredential - WebAuthn credential for authentication
 * @param {boolean} options.useKeystoreDID - If true, creates DID from keystore instead of P-256 DID from WebAuthn
 * @param {Object} options.keystore - OrbitDB keystore instance (required if useKeystoreDID is true)
 * @param {string} options.keystoreKeyType - Key type for keystore: 'secp256k1' (default) or 'Ed25519'
 * @param {boolean} options.encryptKeystore - If true, encrypts the keystore with WebAuthn-protected secret
 * @param {string} options.keystoreEncryptionMethod - Encryption method: 'largeBlob' or 'hmac-secret'
 * @param {string} [options.signingKeyType] - PRF-derived signing key type: 'secp256k1' (default) or 'Ed25519'
 * @returns {Function} Provider factory for OrbitDB.
 */
export function OrbitDBWebAuthnIdentityProviderFunction(options = {}) {
  // Return a function that returns a promise (as expected by OrbitDB)
  return async () => {
    return new OrbitDBWebAuthnIdentityProvider(options);
  };
}

// Add static methods and properties that OrbitDB expects
OrbitDBWebAuthnIdentityProviderFunction.type = IDENTITY_TYPES.WEBAUTHN;
OrbitDBWebAuthnIdentityProviderFunction.verifyIdentity = async function (
  identity
) {
  // The check OrbitDB relies on to decide whether this identity may speak for
  // its DID. It used to accept any `did:key:` of type `webauthn`, so a peer
  // holding only its own key could write as anyone in a write list
  // (GHSA-326j-4cc3-4rrg). See ../webauthn/proof-verification.js.
  if (identity?.type !== IDENTITY_TYPES.WEBAUTHN) return false;
  return verifyWebAuthnIdentityBinding(identity);
};

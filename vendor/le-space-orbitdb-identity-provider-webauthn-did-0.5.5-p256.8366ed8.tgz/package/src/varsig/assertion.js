/**
 * Build and verify WebAuthn varsig assertions for payloads.
 */
import {
  bytesToBase64url,
  decodeWebAuthnVarsigV1,
  encodeWebAuthnVarsigV1,
  parseClientDataJSON,
  reconstructSignedData,
  verifyEd25519Signature,
  verifyP256Signature,
  verifyWebAuthnAssertion,
} from 'iso-webauthn-varsig';
import {
  bindContext,
  buildChallengeBytes,
  toArrayBuffer,
  toBytes,
} from './utils.js';
import { buildCredentialRequestOptions } from '../webauthn/config.js';
import { KEY_TYPES } from '../constants.js';
import {
  VarsigVerificationError,
  WebAuthnAuthenticationError,
} from '../errors.js';
import { logWebAuthnResponse } from '../webauthn/debug-log.js';

/**
 * Run a WebAuthn assertion for a payload.
 * @param {Object} credential - WebAuthn credential info.
 * @param {Uint8Array} payloadBytes - Payload to sign.
 * @param {string} domainLabel - Challenge domain label.
 * @param {'required'|'preferred'|'discouraged'} [userVerification='preferred'] - WebAuthn user verification mode.
 * @param {'silent'|'optional'|'conditional'|'required'} [mediation] - Credential mediation behavior.
 * @param {boolean} [discoverableCredentials] - Override global discoverable credential policy.
 * @returns {Promise<Object>} Assertion metadata and bytes.
 */
async function runWebAuthnAssertionForPayload(
  credential,
  payloadBytes,
  domainLabel,
  userVerification = 'preferred',
  mediation,
  discoverableCredentials
) {
  const rpId = window.location.hostname;
  const origin = window.location.origin;
  // The context is framed into the signed bytes, not into the challenge
  // preimage, so the challenge stays a plain hash of what was signed.
  const signedBytes = bindContext(domainLabel, payloadBytes);
  const challengeBytes = await buildChallengeBytes(signedBytes);

  const assertion = await navigator.credentials.get(
    buildCredentialRequestOptions({
      rpId,
      challenge: challengeBytes,
      credentialId: toArrayBuffer(credential.credentialId),
      userVerification,
      mediation,
      discoverableCredentials,
    })
  );

  if (!assertion) {
    throw new WebAuthnAuthenticationError('Passkey authentication failed.');
  }

  logWebAuthnResponse('varsig navigator.credentials.get()', assertion);

  const response = assertion.response;

  return {
    rpId,
    origin,
    challengeBytes,
    algorithm: credential.algorithm,
    publicKey: credential.publicKey,
    assertion: {
      authenticatorData: new Uint8Array(response.authenticatorData),
      clientDataJSON: new Uint8Array(response.clientDataJSON),
      signature: new Uint8Array(response.signature),
    },
  };
}

/**
 * Build varsig envelope and validate the assertion.
 * @param {Object} assertionData - Assertion metadata from WebAuthn.
 * @returns {Promise<{varsig: Uint8Array, clientData: Object, verification: Object, signatureValid: boolean}>}
 */
async function buildVarsigOutput(assertionData) {
  const { assertion, algorithm, origin, rpId, challengeBytes, publicKey } =
    assertionData;

  const varsig = encodeWebAuthnVarsigV1(assertion, algorithm);
  const decoded = decodeWebAuthnVarsigV1(varsig);
  const clientData = parseClientDataJSON(decoded.clientDataJSON);

  const verification = await verifyWebAuthnAssertion(decoded, {
    expectedOrigin: origin,
    expectedRpId: rpId,
    expectedChallenge: challengeBytes,
  });

  const signedData = await reconstructSignedData(decoded);

  // verifyP256Signature takes the signature as the authenticator returned it
  // (DER) and converts it itself. Unwrapping it here first broke two ways:
  // the unwrapper did not pad a short r or s to 32 bytes, and a raw r‖s that
  // starts with 0x30 was then taken for DER again. About one genuine
  // signature in 90 was refused.
  const signatureValid =
    algorithm === KEY_TYPES.ED25519
      ? await verifyEd25519Signature(signedData, decoded.signature, publicKey)
      : await verifyP256Signature(signedData, decoded.signature, publicKey);

  if (!verification.valid || !signatureValid) {
    throw new VarsigVerificationError('WebAuthn varsig verification failed.');
  }

  return { varsig, clientData, verification, signatureValid };
}

/**
 * Resolve algorithm name from a public key.
 * @param {Uint8Array} publicKey - Raw public key bytes.
 * @returns {string} Algorithm name.
 */
function algorithmFromPublicKey(publicKey) {
  if (publicKey.length === 32) {
    return KEY_TYPES.ED25519;
  }
  if (publicKey.length === 65 && publicKey[0] === 0x04) {
    return KEY_TYPES.P256;
  }
  throw new VarsigVerificationError('Unsupported public key format');
}

/**
 * True when the signature bytes are not a WebAuthn varsig v1 envelope (e.g. worker WebAuthn entry sigs).
 * Callers can fall back to standard OrbitDB/WebAuthn verification.
 * @param {unknown} err - Caught error from decodeWebAuthnVarsigV1.
 * @returns {boolean}
 */
export function isUnsupportedVarsigEnvelopeError(err) {
  return String(err?.message || '')
    .toLowerCase()
    .includes('unsupported varsig header');
}

/**
 * Verify varsig signature for a payload and domain.
 * @param {Uint8Array} signature - Varsig signature.
 * @param {Uint8Array} publicKey - Public key bytes.
 * @param {Uint8Array} payloadBytes - Signed payload bytes.
 * @param {string} domainLabel - Challenge domain label.
 * @returns {Promise<boolean>} True if valid.
 */
async function verifyVarsigForPayload(
  signature,
  publicKey,
  payloadBytes,
  domainLabel
) {
  let decoded;
  try {
    decoded = decodeWebAuthnVarsigV1(signature);
  } catch (err) {
    // Worker / keystore WebAuthn signatures are not varsig envelopes; let hybrid verifiers try fallback.
    if (isUnsupportedVarsigEnvelopeError(err)) {
      return false;
    }
    throw err;
  }
  const clientData = parseClientDataJSON(decoded.clientDataJSON);
  const expectedChallenge = await buildChallengeBytes(
    bindContext(domainLabel, payloadBytes)
  );
  const expectedChallengeEncoded = bytesToBase64url(expectedChallenge);

  if (clientData.challenge !== expectedChallengeEncoded) {
    return false;
  }

  const verification = await verifyWebAuthnAssertion(decoded, {
    expectedOrigin: window.location.origin,
    expectedRpId: window.location.hostname,
    expectedChallenge,
  });

  if (!verification.valid) {
    return false;
  }

  const signedData = await reconstructSignedData(decoded);

  // The DER signature goes to the verifier as is; see buildVarsigOutput.
  const algorithm = algorithmFromPublicKey(publicKey);
  return algorithm === 'Ed25519'
    ? verifyEd25519Signature(signedData, decoded.signature, publicKey)
    : verifyP256Signature(signedData, decoded.signature, publicKey);
}

export {
  algorithmFromPublicKey,
  buildVarsigOutput,
  runWebAuthnAssertionForPayload,
  verifyVarsigForPayload,
  toBytes,
};
